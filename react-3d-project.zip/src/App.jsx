import "./App.css";
import { Canvas } from "@react-three/fiber";
import { Suspense, useRef } from "react";
import Ring, { ExportButton } from "../public/Ring";
import { ContactShadows, Environment, OrbitControls } from "@react-three/drei";
import CustomRing from "../public/Custom_ring";

function App() {
  const groupRef = useRef(null);

  return (
    // <div>
    //   <ThreeScene />
    // </div>
    <>
      <Canvas>
        <ambientLight intensity={4} />
        <OrbitControls />
        <Suspense fallback={null}>
          <Ring groupRef={groupRef} />
          {/* <CustomRing /> */}
        </Suspense>
        <Environment preset="sunset" />
        <ContactShadows
          position={[0, -4.5, 0]}
          opacity={1}
          scale={60}
          blur={1}
          far={10}
          resolution={512}
          color="#000000"
        />
      </Canvas>
      <ExportButton groupRef={groupRef} />
    </>
  );
}

export default App;
