// src/Scene.js
import React, { useRef, useEffect, useState } from "react";
import { Canvas } from "@react-three/fiber";
import { Environment, OrbitControls, useGLTF } from "@react-three/drei";
import { useControls } from "leva";
import * as Three from "three";

const Model = ({ url }) => {
  const { scene } = useGLTF(url);
  const modelRef = useRef();

  // Get values from the GUI controls (using Leva)
  const { color, opacity, scale, materialType } = useControls({
    color: { value: "#123bde", label: "Model Color" },
    opacity: { value: 1, min: 0, max: 1, label: "Opacity" },
    scale: { value: 1, min: 0.1, max: 5, step: 0.1, label: "Scale" },
    materialType: {
      value: "standard",
      options: ["standard", "lambert"],
      label: "Material Type",
    },
  });

  useEffect(() => {
    modelRef.current?.traverse((child) => {
      if (child?.isMesh) {
        console.log(child);
        // Set the material color
        child.material?.color?.set(color);

        // Set the material type based on the selection
        // new THREE.MeshLambertMaterial({ color: color });
        if (materialType === "lambert") {
          child.material = new Three.MeshLambertMaterial({ color: color });
        } else {
          child.material = new Three.MeshStandardMaterial({ color: color });
        }

        // Apply opacity
        child.material.opacity = opacity;
        child.material.transparent = opacity < 1;

        // Apply scale
        child.scale.set(scale, scale, scale);
      }
    });
  }, [color, opacity, scale, materialType]);

  return <primitive object={scene} ref={modelRef} />;
};

const ThreeScene = () => {
  return (
    <div>
      {/* The Canvas and 3D scene */}
      <Canvas style={{ height: "100vh" }}>
        <ambientLight intensity={0.5} />
        <directionalLight position={[5, 5, 5]} intensity={1} />
        <Model url="/ring.gltf" />
        <Environment preset="sunset" />
        <OrbitControls />
      </Canvas>
    </div>
  );
};

export default ThreeScene;
